KC_GRV,  KC_1,    KC_2,    KC_3,    KC_4,    KC_5,    KC_6,
KC_7,    KC_8,    KC_9,    KC_0,    KC_MINS, KC_EQL,  KC_BSPC,          
KC_DEL,  KC_NLCK, KC_PSLS, KC_PAST, KC_PMNS, KC_TAB,  KC_Q,    
KC_W,    KC_E,    KC_R,    KC_T,    KC_Y,    KC_U,    KC_I,    
KC_O,    KC_P,    KC_LBRC, KC_RBRC, KC_BSLS, KC_HOME, KC_P7,
KC_P8,   KC_P9,   KC_PPLS, KC_CAPS, KC_A,    KC_S,    KC_D,
KC_F,    KC_G,    KC_H,    KC_J,    KC_K,    KC_L,    KC_SCLN,
KC_QUOT, KC_ENT,  KC_PGUP, KC_P4,   KC_P5,   KC_P6,   KC_LSFT,
KC_Z,    KC_X,    KC_C,    KC_V,    KC_B,    KC_N,    KC_M,    
KC_COMM, KC_DOT,  KC_SLSH, KC_LSFT, KC_UP,   KC_PGDN, KC_P1,   
KC_P2,   KC_P3,   KC_PENT, KC_LCTL, KC_LGUI, KC_LALT, KC_SPC,   
KC_LALT, RESET,   KC_LEFT, KC_DOWN, KC_RGHT, KC_P0,   KC_PDOT

KC_GRV,  KC_2,    KC_4,    KC_6,    KC_8,    KC_0,    KC_EQL,
KC_1,    KC_3,    KC_5,    KC_7,    KC_9,    KC_MINS, KC_BSPC,          
KC_TAB,  KC_W,    KC_R,    KC_Y,    KC_I,    KC_P,    KC_RBRC,    
KC_Q,    KC_E,    KC_T,    KC_U,    KC_O,    KC_LBRC, KC_BSLS,    
KC_CAPS, KC_S,    KC_F,    KC_H,    KC_K,    KC_SCLN, KC_ENT,
KC_A,    KC_D,    KC_G,    KC_J,    KC_L,    KC_QUOT, KC_NO,
KC_LSFT, KC_X,    KC_V,    KC_N,    KC_COMM, KC_SLSH, KC_UP,
KC_Z,    KC_C,    KC_B,    KC_M,    KC_DOT,  KC_RSFT, KC_NO,
KC_LCTL, KC_LALT, KC_RCTL, KC_LEFT, KC_RIGHT,KC_NO,   KC_NO,    
KC_LGUI, KC_SPC,  RESET,   KC_DOWN, KC_NO,   KC_NO,   KC_NO, 


KC_NLCK, KC_PSLS, KC_PAST, KC_PMNS, KC_NO,   KC_NO,   KC_NO,   
KC_P7,   KC_P8,   KC_P9,   KC_PPLS, KC_NO,   KC_NO,   KC_NO